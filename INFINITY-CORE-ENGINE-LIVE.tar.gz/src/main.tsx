import React from 'react';
import ReactDOM from 'react-dom/client';
import * as Tone from 'tone';
import { InfinityCoreEngine } from './modules/InfinityCoreEngine';
import './styles.css';

// Initialize Tone.js audio context on first user interaction
const initAudio = async () => {
  if (Tone.Synth.prototype.constructor.name === 'Synth') {
    await Tone.start();
    console.log('🔊 Audio context initialized');
  }
};

// Listen for any user interaction to start audio
document.addEventListener('click', initAudio, { once: true });
document.addEventListener('keydown', initAudio, { once: true });
document.addEventListener('touchstart', initAudio, { once: true });

const root = document.getElementById('root');
if (!root) throw new Error('Root element not found');

ReactDOM.createRoot(root).render(
  <React.StrictMode>
    <InfinityCoreEngine />
  </React.StrictMode>,
);
