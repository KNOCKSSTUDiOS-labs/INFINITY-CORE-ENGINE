import { create } from 'zustand';

interface SystemStatus {
  name: string;
  status: 'ok' | 'warning' | 'error';
  value: number | string;
}

interface EngineState {
  isBooting: boolean;
  isOnline: boolean;
  bootProgress: number;
  cpuUsage: number;
  memoryUsage: number;
  uptime: number;
  renderCount: number;
  systemStatus: SystemStatus[];
  activeModule: string;
  soundEnabled: boolean;
  
  setBooting: (value: boolean) => void;
  setOnline: (value: boolean) => void;
  setBootProgress: (value: number) => void;
  setCpuUsage: (value: number) => void;
  setMemoryUsage: (value: number) => void;
  incrementUptime: () => void;
  incrementRenderCount: () => void;
  setSystemStatus: (status: SystemStatus[]) => void;
  setActiveModule: (module: string) => void;
  setSoundEnabled: (enabled: boolean) => void;
  reset: () => void;
}

const initialState = {
  isBooting: true,
  isOnline: false,
  bootProgress: 0,
  cpuUsage: 5,
  memoryUsage: 128,
  uptime: 0,
  renderCount: 0,
  systemStatus: [
    { name: 'Core Engine', status: 'ok' as const, value: 'READY' },
    { name: 'GPU Pipeline', status: 'ok' as const, value: 'ACCELERATED' },
    { name: 'Audio Engine', status: 'ok' as const, value: 'ACTIVE' },
    { name: 'Sentinel', status: 'ok' as const, value: 'ARMED' },
    { name: 'Network', status: 'ok' as const, value: 'CONNECTED' },
    { name: 'Storage', status: 'ok' as const, value: 'OPTIMAL' },
  ],
  activeModule: 'dashboard',
  soundEnabled: true,
};

export const useEngineStore = create<EngineState>((set) => ({
  ...initialState,

  setBooting: (value) => set({ isBooting: value }),
  setOnline: (value) => set({ isOnline: value }),
  setBootProgress: (value) => set({ bootProgress: Math.min(100, value) }),
  setCpuUsage: (value) => set({ cpuUsage: Math.min(100, value) }),
  setMemoryUsage: (value) => set({ memoryUsage: value }),
  
  incrementUptime: () =>
    set((state) => ({ uptime: state.uptime + 1 })),
  
  incrementRenderCount: () =>
    set((state) => ({ renderCount: state.renderCount + 1 })),
  
  setSystemStatus: (status) => set({ systemStatus: status }),
  setActiveModule: (module) => set({ activeModule: module }),
  setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),
  
  reset: () => set(initialState),
}));
