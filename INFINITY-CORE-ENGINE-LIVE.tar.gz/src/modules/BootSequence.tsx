import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useEngineStore } from '../hooks/useEngineStore';
import { soundEngine } from '../utils/SoundEngine';

export const BootSequence: React.FC = () => {
  const { bootProgress, setBootProgress, setBooting, setOnline } = useEngineStore();

  useEffect(() => {
    soundEngine.playStartupSequence();

    const interval = setInterval(() => {
      setBootProgress(bootProgress + Math.random() * 25);
    }, 300);

    if (bootProgress >= 100) {
      clearInterval(interval);
      setTimeout(() => {
        setBooting(false);
        setOnline(true);
      }, 800);
    }

    return () => clearInterval(interval);
  }, [bootProgress, setBootProgress, setBooting, setOnline]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="boot-screen"
      style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #02030a 0%, #0a0f1f 50%, #02030a 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '20px',
      }}
    >
      <motion.div
        animate={{ scale: [1, 1.2, 1] }}
        transition={{ duration: 2, repeat: Infinity }}
        style={{ fontSize: '64px', marginBottom: '24px' }}
      >
        ∞
      </motion.div>

      <motion.h1
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        style={{
          fontFamily: "'Orbitron', monospace",
          fontSize: '32px',
          letterSpacing: '0.1em',
          marginBottom: '8px',
          color: '#fff',
          textShadow: '0 0 20px rgba(0, 240, 255, 0.5)',
        }}
      >
        INFINITY-CORE-ENGINE
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: '12px',
          letterSpacing: '0.15em',
          color: '#8b90a5',
          textTransform: 'uppercase',
          marginBottom: '32px',
        }}
      >
        Initializing Systems...
      </motion.p>

      <motion.div
        style={{
          width: '300px',
          height: '4px',
          background: 'rgba(0, 240, 255, 0.2)',
          borderRadius: '2px',
          overflow: 'hidden',
          marginBottom: '16px',
        }}
      >
        <motion.div
          animate={{ width: `${bootProgress}%` }}
          transition={{ duration: 0.3 }}
          style={{
            height: '100%',
            background: 'linear-gradient(90deg, #00f0ff, #4af2c5)',
            boxShadow: '0 0 20px rgba(0, 240, 255, 0.5)',
          }}
        />
      </motion.div>

      <motion.p
        animate={{ opacity: [0.5, 1] }}
        transition={{ duration: 1, repeat: Infinity }}
        style={{
          fontFamily: "'Space Mono', monospace",
          fontSize: '11px',
          color: '#00ff88',
          letterSpacing: '0.1em',
        }}
      >
        {Math.round(bootProgress)}%
      </motion.p>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        style={{
          marginTop: '40px',
          fontFamily: "'Space Mono', monospace",
          fontSize: '10px',
          color: '#00ff88',
          letterSpacing: '0.15em',
          textTransform: 'uppercase',
        }}
      >
        ✓ Audio Engine Ready
      </motion.div>
    </motion.div>
  );
};
