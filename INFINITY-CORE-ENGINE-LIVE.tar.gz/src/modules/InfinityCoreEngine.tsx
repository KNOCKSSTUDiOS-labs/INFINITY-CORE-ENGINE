import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useEngineStore } from '../hooks/useEngineStore';
import { soundEngine } from '../utils/SoundEngine';
import { BootSequence } from './BootSequence';
import { Dashboard } from './Dashboard';

const MODULES = [
  { id: 'dashboard', name: 'Dashboard', icon: '⚡' },
  { id: 'studio', name: 'AI Studio', icon: '🤖' },
  { id: 'video', name: 'Video Lab', icon: '🎬' },
  { id: 'audio', name: 'Audio Engine', icon: '🎵' },
  { id: 'effects', name: 'Effects', icon: '✨' },
  { id: 'render', name: 'Render', icon: '⚙️' },
];

export const InfinityCoreEngine: React.FC = () => {
  const { isBooting, isOnline, activeModule, setActiveModule, soundEnabled, setSoundEnabled } =
    useEngineStore();
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const handleModuleClick = (moduleId: string) => {
    if (soundEnabled) {
      soundEngine.playClick();
    }
    setActiveModule(moduleId);
  };

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled);
    if (!soundEnabled) {
      soundEngine.playBeep();
    }
  };

  if (isBooting) {
    return <BootSequence />;
  }

  return (
    <div className="ice-root">
      {/* Header */}
      <motion.div
        className="ice-header"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="ice-header-top">
          <div className="ice-logo">
            <motion.span
              className="ice-symbol"
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            >
              ∞
            </motion.span>
            <span>
              ICE <span style={{ fontSize: '12px', letterSpacing: '0.15em' }}>v3.0</span>
            </span>
          </div>

          <div style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
            <motion.span
              className="ice-status"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              LIVE
            </motion.span>

            <button
              onClick={toggleSound}
              style={{
                background: soundEnabled ? 'linear-gradient(135deg, #00f0ff, #4af2c5)' : '#333',
                padding: '6px 14px',
                borderRadius: '6px',
                border: 'none',
                cursor: 'pointer',
                color: soundEnabled ? '#000' : '#fff',
                fontSize: '12px',
                fontWeight: 600,
              }}
            >
              {soundEnabled ? '🔊' : '🔇'}
            </button>

            <motion.span
              style={{
                fontFamily: "'Space Mono', monospace",
                fontSize: '11px',
                color: '#8b90a5',
                letterSpacing: '0.1em',
              }}
              animate={{ opacity: [0.5, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              {time.toLocaleTimeString()}
            </motion.span>
          </div>
        </div>

        <h1 className="ice-title">INFINITY-CORE-ENGINE</h1>
        <p className="ice-subtitle">Production Creative Suite — Fully Animated & Live</p>
      </motion.div>

      {/* Navigation */}
      <motion.nav
        className="ice-nav"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        {MODULES.map((module) => (
          <motion.button
            key={module.id}
            className={`ice-nav-item ${activeModule === module.id ? 'active' : ''}`}
            onClick={() => handleModuleClick(module.id)}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <span>{module.icon}</span>
            <span>{module.name}</span>
          </motion.button>
        ))}
      </motion.nav>

      {/* Main Content */}
      <AnimatePresence mode="wait">
        <motion.main
          key={activeModule}
          className="ice-main"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {activeModule === 'dashboard' && <Dashboard />}

          {activeModule === 'studio' && (
            <div className="ice-panel">
              <h2>AI Studio</h2>
              <p className="ice-panel-desc">Generate images, videos, and creative content</p>
              <motion.div
                style={{
                  marginTop: '16px',
                  padding: '12px',
                  background: 'rgba(0, 240, 255, 0.05)',
                  borderRadius: '6px',
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Coming soon — Advanced AI generation tools
              </motion.div>
            </div>
          )}

          {activeModule === 'video' && (
            <div className="ice-panel">
              <h2>Video Lab</h2>
              <p className="ice-panel-desc">Full video editing and rendering suite</p>
              <motion.div
                style={{
                  marginTop: '16px',
                  padding: '12px',
                  background: 'rgba(0, 240, 255, 0.05)',
                  borderRadius: '6px',
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Coming soon — Professional video tools
              </motion.div>
            </div>
          )}

          {activeModule === 'audio' && (
            <div className="ice-panel">
              <h2>Audio Engine</h2>
              <p className="ice-panel-desc">Sound synthesis and music production</p>
              <motion.div
                style={{
                  marginTop: '16px',
                  display: 'flex',
                  gap: '8px',
                  flexWrap: 'wrap',
                }}
              >
                <button onClick={() => soundEngine.playBeep(400, 0.2)}>Low Tone</button>
                <button onClick={() => soundEngine.playBeep(800, 0.2)}>Mid Tone</button>
                <button onClick={() => soundEngine.playBeep(1200, 0.2)}>High Tone</button>
                <button onClick={() => soundEngine.playSuccess()}>Success Sound</button>
              </motion.div>
            </div>
          )}

          {activeModule === 'effects' && (
            <div className="ice-panel">
              <h2>Effects</h2>
              <p className="ice-panel-desc">Visual and audio effects suite</p>
              <motion.div
                style={{
                  marginTop: '16px',
                  padding: '12px',
                  background: 'rgba(0, 240, 255, 0.05)',
                  borderRadius: '6px',
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Coming soon — Advanced effects library
              </motion.div>
            </div>
          )}

          {activeModule === 'render' && (
            <div className="ice-panel">
              <h2>Render Engine</h2>
              <p className="ice-panel-desc">GPU-accelerated rendering pipeline</p>
              <motion.div
                style={{
                  marginTop: '16px',
                  padding: '12px',
                  background: 'rgba(0, 240, 255, 0.05)',
                  borderRadius: '6px',
                }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                Coming soon — Production rendering tools
              </motion.div>
            </div>
          )}
        </motion.main>
      </AnimatePresence>

      {/* Footer */}
      <motion.footer
        className="ice-footer"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <p>© 2026 KNOCKS Hollywood MOTiON Pictures · INFINITY-CORE-ENGINE v3.0</p>
        <p style={{ marginTop: '12px', fontSize: '10px' }}>
          <a href="https://github.com/KNOCKSSTUDiOS-labs/INFINITY-CORE-ENGINE" target="_blank" rel="noopener noreferrer">
            GitHub Repository
          </a>
          {' • '}
          <a href="https://hollywoodimaging.studio" target="_blank" rel="noopener noreferrer">
            Visit Studio
          </a>
        </p>
      </motion.footer>
    </div>
  );
};
