import React, { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useEngineStore } from '../hooks/useEngineStore';
import { soundEngine } from '../utils/SoundEngine';

export const Dashboard: React.FC = () => {
  const {
    cpuUsage,
    memoryUsage,
    uptime,
    renderCount,
    systemStatus,
    setCpuUsage,
    setMemoryUsage,
    incrementUptime,
    incrementRenderCount,
  } = useEngineStore();

  useEffect(() => {
    const cpuInterval = setInterval(() => {
      setCpuUsage(Math.random() * 40 + 10);
    }, 2000);

    const memInterval = setInterval(() => {
      setMemoryUsage(Math.floor(Math.random() * 150 + 120));
    }, 2000);

    const uptimeInterval = setInterval(() => {
      incrementUptime();
    }, 1000);

    const renderInterval = setInterval(() => {
      incrementRenderCount();
    }, 33); // ~30fps

    return () => {
      clearInterval(cpuInterval);
      clearInterval(memInterval);
      clearInterval(uptimeInterval);
      clearInterval(renderInterval);
    };
  }, [setCpuUsage, setMemoryUsage, incrementUptime, incrementRenderCount]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* Status Panel */}
      <motion.div variants={itemVariants} className="ice-panel">
        <div className="ice-panel-head">
          <h2>System Status</h2>
          <p className="ice-panel-desc">All systems operational</p>
        </div>
        <div className="ice-content">
          {systemStatus.map((stat, i) => (
            <motion.div
              key={stat.name}
              className={`ice-stat ${stat.status}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <span className="ice-stat-label">
                <span className={`ice-indicator ${stat.status}`} />
                {stat.name}
              </span>
              <span className="ice-stat-value">{stat.value}</span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Performance Metrics */}
      <motion.div variants={itemVariants} className="ice-panel">
        <div className="ice-panel-head">
          <h2>Performance</h2>
          <p className="ice-panel-desc">Real-time metrics</p>
        </div>
        <div className="ice-content">
          <div className="ice-stat">
            <span className="ice-stat-label">CPU Usage</span>
            <span className="ice-stat-value">{Math.round(cpuUsage)}%</span>
          </div>
          <motion.div
            style={{
              height: '4px',
              background: 'rgba(0, 240, 255, 0.1)',
              borderRadius: '2px',
              margin: '8px 0',
              overflow: 'hidden',
            }}
          >
            <motion.div
              animate={{ width: `${cpuUsage}%` }}
              transition={{ duration: 0.3 }}
              style={{
                height: '100%',
                background: 'linear-gradient(90deg, #00f0ff, #4af2c5)',
                boxShadow: '0 0 10px rgba(0, 240, 255, 0.5)',
              }}
            />
          </motion.div>

          <div className="ice-stat">
            <span className="ice-stat-label">Memory</span>
            <span className="ice-stat-value">{Math.round(memoryUsage)}MB</span>
          </div>
          <motion.div
            style={{
              height: '4px',
              background: 'rgba(0, 240, 255, 0.1)',
              borderRadius: '2px',
              overflow: 'hidden',
            }}
          >
            <motion.div
              animate={{ width: `${(memoryUsage / 500) * 100}%` }}
              transition={{ duration: 0.3 }}
              style={{
                height: '100%',
                background: 'linear-gradient(90deg, #00ff88, #00f0ff)',
                boxShadow: '0 0 10px rgba(0, 255, 136, 0.5)',
              }}
            />
          </motion.div>

          <div className="ice-stat">
            <span className="ice-stat-label">Uptime</span>
            <span className="ice-stat-value">{formatTime(uptime)}</span>
          </div>

          <div className="ice-stat">
            <span className="ice-stat-label">Frames Rendered</span>
            <span className="ice-stat-value">{renderCount.toLocaleString()}</span>
          </div>
        </div>
      </motion.div>

      {/* Controls */}
      <motion.div variants={itemVariants} className="ice-panel">
        <div className="ice-panel-head">
          <h2>Controls</h2>
          <p className="ice-panel-desc">Engine operations</p>
        </div>
        <div className="ice-content">
          <button
            onClick={() => soundEngine.playSuccess()}
            style={{ width: '100%', marginBottom: '8px' }}
          >
            ▶ Test Audio
          </button>
          <button
            onClick={() => soundEngine.playClick()}
            style={{ width: '100%', marginBottom: '8px' }}
          >
            🔊 Play Click
          </button>
          <button onClick={() => window.location.reload()} style={{ width: '100%' }}>
            ⟳ Restart Engine
          </button>
        </div>
      </motion.div>

      {/* Info */}
      <motion.div variants={itemVariants} className="ice-panel">
        <div className="ice-panel-head">
          <h2>Information</h2>
          <p className="ice-panel-desc">Engine details</p>
        </div>
        <div className="ice-content">
          <div className="ice-stat">
            <span className="ice-stat-label">Version</span>
            <span className="ice-stat-value">3.0.0</span>
          </div>
          <div className="ice-stat">
            <span className="ice-stat-label">Build</span>
            <span className="ice-stat-value">Vite + React</span>
          </div>
          <div className="ice-stat">
            <span className="ice-stat-label">Runtime</span>
            <span className="ice-stat-value">Node 22</span>
          </div>
          <div className="ice-stat">
            <span className="ice-stat-label">Audio Engine</span>
            <span className="ice-stat-value">Tone.js</span>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

function formatTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}h ${m}m ${s}s`;
}
