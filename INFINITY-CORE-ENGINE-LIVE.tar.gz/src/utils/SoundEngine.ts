import * as Tone from 'tone';

export class SoundEngine {
  private synth: Tone.PolySynth<Tone.Synth>;
  private volume: Tone.Volume;
  private reverb: Tone.Reverb;
  private delay: Tone.Delay;
  private isInitialized = false;

  constructor() {
    this.volume = new Tone.Volume(-12).toDestination();
    this.reverb = new Tone.Reverb({
      decay: 2.5,
    }).connect(this.volume);

    this.delay = new Tone.Delay({
      time: '8n',
      feedback: 0.2,
      wet: 0.3,
    }).connect(this.reverb);

    this.synth = new Tone.PolySynth(Tone.Synth, {
      oscillator: { type: 'triangle' },
      envelope: {
        attack: 0.005,
        decay: 0.1,
        sustain: 0.3,
        release: 1,
      },
    }).connect(this.delay);
  }

  async initialize() {
    if (this.isInitialized) return;
    await Tone.start();
    this.isInitialized = true;
  }

  // Boot sequence sound
  playBootSound() {
    this.synth.triggerAttackRelease('C4', '8n');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('E4', '8n');
    }, '+0.1');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('G4', '16n');
    }, '+0.2');
  }

  // Status indicator beep
  playBeep(frequency: number = 800, duration: number = 0.1) {
    const beep = new Tone.Sine(frequency).connect(this.volume);
    beep.start();
    Tone.Transport.scheduleOnce(() => {
      beep.stop();
    }, `+${duration}`);
  }

  // Success notification
  playSuccess() {
    this.synth.triggerAttackRelease('E4', '16n');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('G4', '16n');
    }, '+0.05');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('C5', '8n');
    }, '+0.1');
  }

  // Warning sound
  playWarning() {
    this.synth.triggerAttackRelease('A3', '8n');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('A3', '8n');
    }, '+0.2');
  }

  // Error sound
  playError() {
    this.synth.triggerAttackRelease('D2', '8n');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('D2', '8n');
    }, '+0.15');
    Tone.Transport.scheduleOnce(() => {
      this.synth.triggerAttackRelease('D2', '8n');
    }, '+0.3');
  }

  // Ambient loop
  playAmbient() {
    const now = Tone.now();
    const notes = ['C2', 'E2', 'G2', 'C3'];
    
    notes.forEach((note, i) => {
      Tone.Transport.scheduleOnce(() => {
        this.synth.triggerAttackRelease(note, '2n');
      }, now + i * 0.5);
    });
  }

  // Click sound
  playClick() {
    const osc = new Tone.Oscillator({
      frequency: 1200,
      type: 'square',
    }).connect(this.volume);

    const env = new Tone.Envelope({
      attack: 0.001,
      decay: 0.05,
      sustain: 0,
      release: 0.01,
    });

    env.connect(osc.frequency);
    osc.start();
    env.trigger();

    Tone.Transport.scheduleOnce(() => {
      osc.stop();
    }, '+0.05');
  }

  // Startup sequence
  async playStartupSequence() {
    await this.initialize();
    
    this.playBootSound();
    Tone.Transport.scheduleOnce(() => {
      this.playBeep(1000, 0.15);
    }, '+0.5');
    Tone.Transport.scheduleOnce(() => {
      this.playBeep(1200, 0.15);
    }, '+0.75');
    Tone.Transport.scheduleOnce(() => {
      this.playSuccess();
    }, '+1.0');
  }

  setVolume(value: number) {
    this.volume.volume.value = value;
  }

  getVolume(): number {
    return this.volume.volume.value;
  }

  dispose() {
    this.synth.dispose();
    this.volume.dispose();
    this.reverb.dispose();
    this.delay.dispose();
  }
}

// Export singleton instance
export const soundEngine = new SoundEngine();
